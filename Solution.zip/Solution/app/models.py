import datetime
import csv
from collections import OrderedDict

from peewee import *

db = SqliteDatabase('inventory.db')


class CustomIntegerField(TextField):

    def db_value(self, value):
        return ''.join(e for e in value if e.isalnum())

    def python_value(self, value):
        return '$' + value[:-2] + '.' + value[-2:]


class CustomDateField(DateField):

    def db_value(self, value):
        return value

    def python_value(self, value):
        return value


class Product(Model):
    product_id = AutoField(primary_key=True)
    product_name = TextField(unique=True)
    product_price = CustomIntegerField()
    product_quantity = IntegerField()
    date_updated = CustomDateField(formats=['%m/%d/%Y'], default=datetime.datetime.now)

    class Meta:
        database = db


def migrate_data():
    with open('inventory.csv') as csv_file:
        reader = csv.reader(csv_file, delimiter=",")
        keys = next(reader)
        ordered = ([OrderedDict(zip(keys, row)) for row in reader])
        for index, item in enumerate(ordered):
            try:
                Product.create(product_name=item['product_name'],
                               product_price=item['product_price'],
                               product_quantity=item['product_quantity'],
                               date_updated=item['date_updated'])
            except IntegrityError:
                print('Duplicate product name: ' + item['product_name'])
