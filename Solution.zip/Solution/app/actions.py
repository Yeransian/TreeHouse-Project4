import csv
import datetime
from collections import OrderedDict

from peewee import IntegrityError
from playhouse.shortcuts import model_to_dict

from app.models import db, Product


def initialize():
    """ Initialize an Sqlite database called inventory.db."""
    db.connect()
    db.create_tables([Product], safe=True)


def view_entries(search_query=None):
    """View entries"""
    if search_query:
        entries = Product.select().where(Product.product_name.contains(search_query))
    else:
        entries = Product.select().order_by(Product.product_id.asc())
    for entry in entries:
        print("ID: {}, Product Name: {}, Product Price: {}, Product Quantity: {}, Last Updated: {}\n".format(
            entry.product_id, entry.product_name, entry.product_price, entry.product_quantity, entry.date_updated))


def search_entry():
    """Search entries for a string by name"""
    q = input('Search Query: ')
    view_entries(q)


def backup_db():
    """Backup Database to a CSV File"""
    fields = [Product.product_name, Product.product_price, Product.product_quantity, Product.date_updated]
    all_data = Product.select(*fields)
    dicted_data = [model_to_dict(c, only=fields) for c in all_data]

    with open(f'backups\\inventory_backup_{datetime.datetime.now().strftime("%m-%d-%Y")}.csv', mode='w') as csv_file:
        fieldnames = ['product_name', 'product_price', 'product_quantity', 'date_updated']
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

        writer.writeheader()
        writer.writerows(dicted_data)


def add_entry():
    """Add entries to the database"""
    product_name = input('Product name: ')
    product_quantity = input('Product quantity: ')
    product_price = input('Product price: ')
    try:
        Product.create(product_name=product_name, product_quantity=product_quantity, product_price=product_price)
    except IntegrityError as e:
        print(e)
        print('\nProduct not added\n\n')


def id_search():
    """Search for an entry by ID"""
    find_id = input("Enter an ID number: ")
    entry = Product.get_by_id(find_id)
    print("ID: {}, Product Name: {}, Product Price: {}, Product Quantity: {}, Last Updated: {}\n".format(
        entry.product_id, entry.product_name, entry.product_price, entry.product_quantity, entry.date_updated))


def quit_app():
    """Exit App"""
    exit(0)


menu = OrderedDict([
    ('a', add_entry),
    ('v', view_entries),
    ('b', backup_db),
    ('s', search_entry),
    ('id', id_search),
    ('q', quit_app)
])


def menu_loop():
    choice = None
    while choice != 'q':
        for key, value in menu.items():
            print('{}) {}'.format(key, value.__doc__))
        choice = input('Action: ').lower()
        if choice in menu:
            menu[choice]()
        else:
            print(f'Selected menu entry "{choice}" not exist, please choose one from menu below.')
