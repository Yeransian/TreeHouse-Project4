import os

from app.models import migrate_data
from app.actions import initialize, menu_loop

if __name__ == '__main__':
    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'backups')):
        os.makedirs(os.path.join(os.path.dirname(__file__), 'backups'))
    initialize()
    exists = os.path.isfile(os.path.join(os.path.dirname(__file__), 'inventory.db'))
    if not exists:
        migrate_data()
    menu_loop()
